const Router = require('express');

const getFileScannerRouters = (app) => {
    const router = new Router();

    router
        .post('/file', (req, res) => {
            console.log("BEGIN: Scanning...");
            req
                .on('data', chunk => {
                    // scanning chunk
                })
                .on('end', () => {
                    console.log("Done: Scanning...");
                    res.send({
                        "result": "clean",
                    });
                })
                .on('error', (err) => {
                    res.send({
                        "result": "error",
                        "reason": err,
                    })
                });
        });

    app.use('/scan', router);
};

module.exports = getFileScannerRouters;