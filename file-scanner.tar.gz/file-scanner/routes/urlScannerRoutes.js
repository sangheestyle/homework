const Router = require('express');
const config = require('../config.json');
const urlScanner = require('../controllers/urlScanner');

const getUrlScannerRoutes = (app) => {
    const router = new Router();

    router
        .post('/url', (req, res) => {
            const { body: { url } } = req;
            const { domain, endpoint } = config.virusScanningBackend;
            const fileScanUrl = domain + endpoint;

            urlScanner(url, fileScanUrl)
                .then(report => res.send(report))
                .catch(err => {
                    res.send({
                        "result": err,
                    });
                })
        });

    app.use('/scan', router);
};

module.exports = getUrlScannerRoutes;