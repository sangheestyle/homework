# File Scanner

## How to run it locally
Tested with node `v8.9.2` and npm `5.6.0`.

```
$ npm i
$ npm start
```

## How to run the unit tests
```
$ npm test
```

## How to submit a sample URL
```
$ time curl -d '{"url":"http://download.thinkbroadband.com/50MB.zip"}' \
            -H "Content-Type: application/json" \
             -X POST http://localhost:3000/scan/url
{"sha1":"434b03d4ec460c67106dd021973e3f0dee4763b3","result":"clean"}
real	0m10.430s
user	0m0.008s
sys	0m0.008s
```
