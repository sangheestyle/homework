const fs = require('fs');
const nock = require('nock');
const config = require('../../config.json');
const urlScanner = require('../../controllers/urlScanner');


describe('urlScanner with the stable upstream services', () => {
    beforeEach(() => {
        const dummyFilePath = __dirname + '/dummy_1MB_file';
        const fileServer = nock('http://fileserver.com')
                            .defaultReplyHeaders({
                                'content-length': fs.statSync(dummyFilePath)["size"],
                            })
                            .get('/dummy_1MB_file')
                            .reply(200, (uri, requestBody) => {
                                return fs.createReadStream(dummyFilePath);
                            });

        const { domain, endpoint } = config.virusScanningBackend;
        const virusScanningBackend = nock(domain)
                                        .post(endpoint)
                                        .reply(200, {
                                            result: "clean",
                                        });
    });

    test('returns result and sha1 of the scanned file.', async () => {
        const url = "http://fileserver.com/dummy_1MB_file";
        const { domain, endpoint } = config.virusScanningBackend;
        const fileScanUrl = domain + endpoint;
        const data = await urlScanner(url, fileScanUrl);
        expect(data).toEqual({
            result: "clean",
            sha1: "3b71f43ff30f4b15b5cd85dd9e95ebc7e84eb5a3",
        });
    });

});

describe('urlScanner with file server or input errors', () => {
    beforeEach(() => {
        const dummyFilePath = __dirname + '/dummy_1MB_file';
        const fileServer = nock('http://fileserver.com')
                            .defaultReplyHeaders({
                                'content-length': config.maxFileSize + 1,
                            })
                            .get('/dummy_too_big_file')
                            .reply(200, (uri, requestBody) => {
                                return fs.createReadStream(dummyFilePath);
                            });

        // no content-length
        const fileServer2 = nock('http://fileserver2.com')
                            .get('/dummy_1MB_file')
                            .reply(200, (uri, requestBody) => {
                                return fs.createReadStream(dummyFilePath);
                            });
        // Given url is invalid
        const urlInvalidFileServer = nock('http://fileserver.com')
                                    .get('/invalid')
                                    .reply(404);
    });

    const { domain, endpoint } = config.virusScanningBackend;
    const fileScanUrl = domain + endpoint;

    test('rejects a request when a file size > 200MB.', async () => {
        const url = "http://fileserver.com/dummy_too_big_file";
        await expect(urlScanner(url, fileScanUrl))
            .rejects.toEqual({
                error: "File is too big: Largest file size is 200MB.",
            });
    });

    test("rejects a request when GET response from file server doesn't have content-length header.", async () => {
        const url = "http://fileserver2.com/dummy_1MB_file";
        await expect(urlScanner(url, fileScanUrl))
            .rejects.toEqual({
                error: "Require content-length in response header.",
            });
    });

    test("rejects a request when given url is not found on file server(404).", async () => {
        const url = "http://fileserver.com/invalid";
        await expect(urlScanner(url, fileScanUrl))
            .rejects.toEqual({
                error: "Given url for the file is invalid.",
                statusCode: 404,
                url,
            });
    })

    test("rejects a request when given url is invalid.", async () => {
        const url = "eserver.com/invalid";
        await expect(urlScanner(url, fileScanUrl))
            .rejects.toEqual({
                error: `Invalid URI \"${url}\"`,
                url,
            });
    })

    test("rejects a request when given url is empty.", async () => {
        await expect(urlScanner("", fileScanUrl))
            .rejects.toEqual({
                error: "URL is required. Check your URL.",
                url: "",
            });
    })

});

describe('urlScanner with the unstable virus scanning backend', () => {
    beforeEach(() => {
        const dummyFilePath = __dirname + '/dummy_1MB_file';
        const fileServer = nock('http://fileserver.com')
                            .defaultReplyHeaders({
                                'content-length': fs.statSync(dummyFilePath)["size"],
                            })
                            .get('/dummy_1MB_file')
                            .reply(200, (uri, requestBody) => {
                                return fs.createReadStream(dummyFilePath);
                            });
        // wrong endpoint
        const urlInvalidVirusScanServer = nock('http://virusscanner.com')
                                            .post('/invalid')
                                            .reply(404);
        // wrong endpoint
        const brokenVirusScanServer = nock('http://virusscanner.com')
                                        .post('/broken')
                                        .reply(500);
    });

    const fileUri = "http://fileserver.com/dummy_1MB_file"; 

    test('returns error when it is ECONNREFUSED.', async () => {
        const closedPort = 8777;
        const fileScanUrl = `http://localhost:${closedPort}/scan/file`;
        await expect(urlScanner(fileUri, fileScanUrl))
            .rejects.toEqual({
                code: "ECONNREFUSED",
                error: `connect ECONNREFUSED 127.0.0.1:${closedPort}`,
                url: fileScanUrl
            });
    });

    test('returns error when HTTP 404', async () => {
        const fileScanUrl = "http://virusscanner.com/invalid";
        await expect(urlScanner(fileUri, fileScanUrl))
            .rejects.toEqual({
                error: "Got 404 from fileScanUrl",
                statusCode: 404,
                url: fileScanUrl
            });
    });

    test('returns error when HTTP 500', async () => {
        const fileScanUrl = "http://virusscanner.com/broken";
        await expect(urlScanner(fileUri, fileScanUrl))
            .rejects.toEqual({
                error: "Error from fileScanUrl",
                statusCode: 500,
                url: fileScanUrl
            });
    });

});
