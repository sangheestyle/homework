const crypto = require('crypto');
const request = require('request');
const config = require('../config.json');

const urlScanner = (fileUri, fileScanUrl) => new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha1');
    const report = {
        sha1: null,
        result: null,
    };
    request
        .get(fileUri, (err, resp, body) => {
            if (err) {
                if (err.message === "options.uri is a required argument") {
                    reject({
                        error: "URL is required. Check your URL.",
                        url: fileUri,
                    });
                }

                reject({
                    error: err.message,
                    url: fileUri,
                });
            }
        })
        .on('response', (response) => {
            const { statusCode, headers } = response;
            if (statusCode == 404) {
                reject({
                    error: "Given url for the file is invalid.",
                    statusCode,
                    url: fileUri
                });
            }

            const size = headers['content-length'];
            if (size == undefined) {
                reject({
                    error: "Require content-length in response header.",
                });
            }
            if (size > config.maxFileSize) {
                const maxFileSizeMB = config.maxFileSize / 1024 / 1024;
                reject({
                    error: `File is too big: Largest file size is ${maxFileSizeMB}MB.`,
                });
            }
        })
        .on('data', chunk => {
            hash.update(chunk);
        })
        .on('end', () => {
            report.sha1 = hash.digest('hex');
        })
        .pipe(request.post(fileScanUrl))
        .on('error', (err) => {
            reject({
                error: err.message,
                code: err.code,
                url: fileScanUrl,
            });
        })
        .on('response', (response) => {
            const { statusCode } = response;
            if (statusCode !== 200) {
                if (statusCode === 404) {
                    reject({
                        error: "Got 404 from fileScanUrl",
                        url: fileScanUrl,
                        statusCode,
                    });
                } else {
                    reject({
                        error: "Error from fileScanUrl",
                        url: fileScanUrl,
                        statusCode,
                    });
                }
            }

            const data = [];
            response
                .on('data', chunk => {
                    data.push(chunk);
                })
                .on('end', () => {
                    if (data.length) {
                        const { result } = JSON.parse(data.join(''));
                        report.result = result;
                        resolve(report);
                    } else {
                        reject({
                            error: "Empty data: no received data from fileScanUrl",
                            url: fileScanUrl,
                        });
                    }
                });
        });
});

module.exports = urlScanner;